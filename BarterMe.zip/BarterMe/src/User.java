/*This Class is for user objects*/
public class User {
    public User(){

    }
 String firstName;
 String lastName;
 String userName;
 String password;
 String email;
 int id = 0;



 public User(String fN , String lN , String uN , String pass , String em ,int id){
     this.id = id;
        firstName = fN;
        lastName = lN;
        userName = uN;
        password = pass;
        email = em;



    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



}
