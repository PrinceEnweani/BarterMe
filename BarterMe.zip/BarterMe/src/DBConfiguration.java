
public class DBConfiguration {
    public static String username = "root";
    public static String password = "John1009780";
    public static String mysqlURL = "jdbc:mysql://localhost:3306/barterme?useSSL=false";

    public DBConfiguration() {
    }
}
