public class Category {

     int cat_id;
     String category;
    String icon_url;

    public Category(int cat_id, String category, String icon_url) {
        this.cat_id = cat_id;
        this.category = category;
        this.icon_url = icon_url;
    }

    public int getCat_id() {
        return cat_id;
    }

    public void setCat_id(int cat_id) {
        this.cat_id = cat_id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getIcon_url() {
        return icon_url;
    }

    public void setIcon_url(String icon_url) {
        this.icon_url = icon_url;
    }

}
