public class Product {
    int prod_id;
    int cat_id;
    String name;
    String desc;
    String picUrl;
    double price;
    int quantity;
    int taxable;
    double discount;

    public Product(int prod_id, int cat_id, String name, String desc, String picUrl, double price, int quantity, int taxable) {
        this.prod_id = prod_id;
        this.cat_id = cat_id;
        this.name = name;
        this.desc = desc;
        this.picUrl = picUrl;
        this.price = price;
        this.quantity = quantity;
        this.taxable = taxable;
    }

    public int getProd_id() {
        return prod_id;
    }

    public void setProd_id(int prod_id) {
        this.prod_id = prod_id;
    }

    public int getCat_id() {
        return cat_id;
    }

    public void setCat_id(int cat_id) {
        this.cat_id = cat_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getTaxable() {
        return taxable;
    }

    public void setTaxable(int taxable) {
        this.taxable = taxable;
    }


}
