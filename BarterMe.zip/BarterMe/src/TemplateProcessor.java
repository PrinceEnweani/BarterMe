import freemarker.template.*;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;

public class TemplateProcessor {
    private String templateDirectory;
    private String templateName;
    private Configuration configuration;

    public TemplateProcessor(String tempDir, ServletContext serCtx) {
        this.templateDirectory = tempDir;
        this.configuration = new Configuration(Configuration.VERSION_2_3_28);
        this.configuration.setServletContextForTemplateLoading(serCtx, tempDir);
        this.configuration.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
    }

    public void templateProcessor(String templateName, SimpleHash root, HttpServletRequest request, HttpServletResponse response) {
        this.templateName = templateName;
        Template template = null;

        try {
            template = this.configuration.getTemplate(templateName);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            Writer out = response.getWriter();
            response.setContentType("text/html");
            template.process(root, out);
        } catch (TemplateException var7) {
            var7.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
