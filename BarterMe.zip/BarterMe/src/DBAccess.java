//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

import java.sql.*;

public class DBAccess {
    ResultSet rs;

    public DBAccess() {
    }

    public Connection getConnection() {
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DBConfiguration.mysqlURL, DBConfiguration.username, DBConfiguration.password);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return con;
    }

    public void createUser(int id , String fN , String lN , String em , String uN, String pass) {
        Connection con = this.getConnection();
        this.rs = null;

        try {
            Statement st = con.createStatement();
            String sql = "INSERT INTO users (id , first_name , last_name , email , username , password) VALUES (" + id + ",\""+ fN +"\",\""+ lN +"\",\""+ em +"\",\""+ uN +"\",\""+ pass+"\")";
            //INSERT INTO users (id , first_name , last_name , email ,username , password)
            //VALUES (1 , "Prince" , "Enweani" , "pe0051@gmail.cdu" , "Timaden" , "password");
            st.executeUpdate(sql);
        } catch (SQLException var5) {
            var5.printStackTrace();
        }


    }

    public ResultSet loginUser(String username , String password) {
        Connection con = this.getConnection();
        this.rs = null;
        try {
            Statement st = con.createStatement();
            String sql =  "SELECT * FROM users where username = \"" + username + "\" and password = \"" + password + "\";";
            //INSERT INTO users (id , first_name , last_name , email ,username , password)
            //VALUES (1 , "Prince" , "Enweani" , "pe0051@gmail.cdu" , "Timaden" , "password");
            this.rs = st.executeQuery(sql);
        } catch (SQLException var5) {
            var5.printStackTrace();
        }
        return  this.rs;

    }
    public ResultSet getCategories(){
        Connection con = this.getConnection();
        this.rs = null;
        try{
            Statement st = con.createStatement();
            //Query to grab data from categories table
            String sql = "select * from categories order by category;";
            this.rs = st.executeQuery(sql);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return this.rs;
    }

    public ResultSet getProducts(){
        Connection con = this.getConnection();
        this.rs = null;
        try{
            Statement st = con.createStatement();
            //Query to grab data from products table
            String sql = "SELECT * FROM products LIMIT 8;";
            this.rs = st.executeQuery(sql);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return this.rs;
    }
}
