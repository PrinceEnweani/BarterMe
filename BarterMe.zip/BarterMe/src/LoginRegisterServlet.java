import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapperBuilder;
import freemarker.template.SimpleHash;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "LoginRegisterServlet")
public class LoginRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String templateDir = "/WEB-INF/templates";
    Configuration cfg;
    private TemplateProcessor processor;
    DBAccess db;
    static int id = 1;

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        this.processor = new TemplateProcessor(this.templateDir, this.getServletContext());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        id++;
        DBAccess db = new DBAccess();
        String dropdownoption = request.getParameter("dropdown");
        String input = request.getParameter("input");
        ResultSet rs;
        String templateName;
        DefaultObjectWrapperBuilder defaultObjectWrapperBuilder;
        SimpleHash root;

        String fN = request.getParameter("firstNameField");
        String lN = request.getParameter("lastNameField");
        String em = request.getParameter("emailField");
        String uN = request.getParameter("userNameField");
        String pass = request.getParameter("passwordField");

       db.createUser(id , fN , lN , em ,uN, pass);
        ArrayList ulist = new ArrayList();

        User u = new User(fN , lN , uN , pass , em , id);

        //ulist.add(u);

        templateName = "home.ftl";
        defaultObjectWrapperBuilder = new DefaultObjectWrapperBuilder(Configuration.VERSION_2_3_28);
        root = new SimpleHash(defaultObjectWrapperBuilder.build());
        root.put("user", u);
        this.processor.templateProcessor(templateName, root, request, response);
        return;
    }
}
