import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapperBuilder;
import freemarker.template.SimpleHash;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Action {

    //Runs the login actions for user login
   public static  void loginDoGet(TemplateProcessor t , HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            //id++;
            //Create Access to our database
            DBAccess db = new DBAccess();
            ResultSet rs;
            User user = new User();
            String templateName;
            DefaultObjectWrapperBuilder defaultObjectWrapperBuilder;
            SimpleHash root;
            String uN = request.getParameter("emailField");
            String pass = request.getParameter("passwordField");
            ArrayList<Category> cList = new ArrayList<>();
            ArrayList<Product> pList = new ArrayList<>();
            ResultSet rsProds;
            ResultSet rsCats;
            //Get the categories
            rsCats = db.getCategories();
            rsProds = db.getProducts();
            while(rsCats.next()){
                Category cat = new Category(rsCats.getInt("cat_id") , rsCats.getString("category") , rsCats.getString("icon"));
                cList.add(cat);
            }
            while(rsProds.next()){

                Product p = new Product(rsProds.getInt("prod_id") , rsProds.getInt("cat_id"), rsProds.getString("name"), rsProds.getString("description"), rsProds.getString("pic_url"), rsProds.getDouble("price"), rsProds.getInt("quantity"), rsProds.getInt("taxable"));
                pList.add(p);
            }

            rs = db.loginUser(uN , pass);
            if(!rs.next()){

            }else {

                //user = new User(rs.getString("first_name") , rs.getString("last_name"), rs.getString("username") , rs.getString("email") , rs.getString("password") , rs.getInt(id));
                user.setFirstName(rs.getString("first_name"));
                user.setLastName(rs.getString("last_name"));
                user.setUserName(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setId(rs.getInt("id"));
                templateName = "home.ftl";
                defaultObjectWrapperBuilder = new DefaultObjectWrapperBuilder(Configuration.VERSION_2_3_28);
                root = new SimpleHash(defaultObjectWrapperBuilder.build());
                root.put("user", user);
                root.put("cList" , cList);
                root.put("pList" , pList);
                t.templateProcessor(templateName, root, request, response);
            }


        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public static void registerDoGet(TemplateProcessor t , HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {

        DBAccess db = new DBAccess();
        ResultSet rs;
        ResultSet rsProds;
        ResultSet rsCats;
        String templateName;
        DefaultObjectWrapperBuilder defaultObjectWrapperBuilder;
        SimpleHash root;

        String fN = request.getParameter("firstNameField");
        String lN = request.getParameter("lastNameField");
        String em = request.getParameter("emailField");
        String uN = request.getParameter("userNameField");
        String pass = request.getParameter("passwordField");
        int id = (int)(Math.random() * 99999 + 1 - 1);
        db.createUser(id , fN , lN , em ,uN, pass);
        ArrayList<Category> cList = new ArrayList<>();
        ArrayList<Product> pList = new ArrayList<>();
        ArrayList ulist = new ArrayList();

        //Get the categories
        rsCats = db.getCategories();
        rsProds = db.getProducts();
        while(rsCats.next()){
           Category cat = new Category(rsCats.getInt("cat_id") , rsCats.getString("category") , rsCats.getString("icon"));
           cList.add(cat);
        }
        while(rsProds.next()){

            Product p = new Product(rsProds.getInt("prod_id") , rsProds.getInt("cat_id"), rsProds.getString("name"), rsProds.getString("description"), rsProds.getString("pic_url"), rsProds.getDouble("price"), rsProds.getInt("quantity"), rsProds.getInt("taxable"));
            pList.add(p);
        }
        User u = new User(fN , lN , uN , pass , em , id);

        //ulist.add(u);

        //Set the template name to load to our homepage
        templateName = "home.ftl";
        defaultObjectWrapperBuilder = new DefaultObjectWrapperBuilder(Configuration.VERSION_2_3_28);
        root = new SimpleHash(defaultObjectWrapperBuilder.build());
        //put the data in the root.
        root.put("user", u);
        root.put("cList" , cList);
        root.put("cList" , pList);
        t.templateProcessor(templateName, root, request, response);
        return;
    }
}
