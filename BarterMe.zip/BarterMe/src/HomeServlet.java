import freemarker.template.Configuration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "HomeServlet" , urlPatterns = "/home")
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String templateDir = "/WEB-INF/templates";
    Configuration cfg;
    private TemplateProcessor processor;
    DBAccess db;
    static int id = 1;

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        this.processor = new TemplateProcessor(this.templateDir, this.getServletContext());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
